import { createApp } from 'vue';
import App from './Components/App.vue';

createApp(App).mount('#app');